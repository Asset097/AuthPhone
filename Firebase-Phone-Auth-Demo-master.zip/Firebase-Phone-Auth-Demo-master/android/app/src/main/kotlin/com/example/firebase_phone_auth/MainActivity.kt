package com.example.firebase_phone_auth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
